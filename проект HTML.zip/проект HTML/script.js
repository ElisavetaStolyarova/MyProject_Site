const themeButton = document.getElementById("theme-toggle")

function applyTheme(theme){
    if(theme == 'dark'){
        document.body.classList.remove('dark-mode');
        themeButton.textContent='Темная тема'
    }else{
        document.body.classList.add('dark-mode');
        themeButton.textContent ="Светлая тема"
    }
    
}

const savedTheme = localStorage.getItem('user-theme');
applyTheme(savedTheme)

themeButton.addEventListener('click', () => {
    let currentTheme
    if(document.body.classList.contains('dark-mode')){
        currentTheme = 'dark'
    }else{
        currentTheme = 'light'
    }
localStorage.setItem('user-theme', currentTheme)
});

themeButton.addEventListener('click', ()=>{ 
    document.body.classList.toggle('dark-mode');
    if(document.body.classList.contains('dark-mode')){
        themeButton.textContent = "Темная тема";
    } else{
        themeButton.textContent = "Светлая тема";
    }
});

function toggleMenu() {
    document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}